﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Backend_SweetAlert.Startup))]
namespace Backend_SweetAlert
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
